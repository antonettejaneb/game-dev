var Height = function (line)
{
    return Math.abs(line.y1 - line.y2);
};

module.exports = Height;
