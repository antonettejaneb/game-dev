module.exports = {

    CACHE_ADD_EVENT: require('./CacheAddEvent'),
    CACHE_REMOVE_EVENT: require('./CacheRemoveEvent')

};
